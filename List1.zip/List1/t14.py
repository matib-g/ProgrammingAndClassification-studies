A = ['a1', 'a2', 'a3']
B = ['b1', 'b2', 'b3']
C = []

for i in range(0, len(A)):
    C.append(A[i])
    C.append(B[i])

print(C)
